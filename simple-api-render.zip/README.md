# Simple API for Render/Railway
This is a simple Node.js Express API ready to deploy on Render.com or Railway.app.
